Documentation for the Diamond City Theme is located at
http://docs.themes.zone/dici/doc.html